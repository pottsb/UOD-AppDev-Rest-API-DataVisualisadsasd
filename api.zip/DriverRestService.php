<?php
    require "dbinfo.php";
    require "RestService.php";
    require "Driver.php";

// Before running this demo, you need to create a database in MySQL called
// wsdrivers and populate it using the script wsdrivers_mysql.sql.  You also need
// to edit the fields in dbinfo.php to refer to the database you are using.
//
// There is limited error handling in this code in order to keep the code as simple as
// possible.
 
class DriverRestService extends RestService 
{
	private $drivers;
    
	public function __construct() 
	{
		// Passing in the string 'drivers' to the base constructor ensures that
		// all calls are matched to be sure they are in the form http://server/drivers/x/y/z 
		parent::__construct("drivers");
	}

	public function performGet($url, $parameters, $requestBody, $accept) 
	{
		switch (count($parameters))
		{
			case 1:
				// Note that we need to specify that we are sending JSON back or
				// the default will be used (which is text/html).
				header('Content-Type: application/json; charset=utf-8');
				// This header is needed to stop IE cacheing the results of the GET	
				header('no-cache,no-store');
				$this->getAlldrivers();
				echo json_encode($this->drivers);
				break;

			case 2:
				$id = $parameters[1];
				$driver = $this->getdriverById($id);
				if ($driver != null)
				{
					header('Content-Type: application/json; charset=utf-8');
					header('no-cache,no-store');
					echo json_encode($driver);
				}
				else
				{
					$this->notFoundResponse();
				}
				break;

			case 4:
				$year = $parameters[1];
				$month = $parameters[2];
				$day = $parameters[3];
				header('Content-Type: application/json; charset=utf-8');
				header('no-cache,no-store');
				$this->getdriversByDate($year, $month, $day);
				echo json_encode($this->drivers);
				break;
				
			default:	
				$this->methodNotAllowedResponse();
		}
	}

	public function performPost($url, $parameters, $requestBody, $accept) 
	{
		global $dbserver, $dbusername, $dbpassword, $dbdatabase;

		$newBook = $this->extractDriverFromJSON($requestBody);
		$connection = new mysqli($dbserver, $dbusername, $dbpassword, $dbdatabase);
		if (!$connection->connect_error)
		{
			$sql = "insert into data (ID, KIDSDRIVE, DOB, AGE, HOMEKIDS, YOJ, INCOME, PARENT, HOME_VAL, MSTATUS, GENDER, EDUCATION, OCCUPATION, TRAVTIME, 
			CAR_USE, BLUEBOOK, TIF, CAR_TYPE, RED_CAR, OLDCLAIM, CLM_FREQ, REVOKED, MVR_PTS, CLM_AMT, CAR_AGE, CLAIM_FLAG, URBANICITY) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			// We pull the fields of the book into local variables since 
			// the parameters to bind_param are passed by reference.
			$statement = $connection->prepare($sql);

			$Id = $newBook->getId();
			$KidsDrive = $newBook->getKidsDrive();
			$DOB = $newBook->getDOB();
			$Age = $newBook->getAge();
			$HomeKids = $newBook->getHomeKids();
			$YOJ = $newBook->getYOJ();
			$Income = $newBook->getIncome();
			$Parent = $newBook->getParent();
			$HomeValue = $newBook->getHomeValue();
			$MStatus = $newBook->getMStatus();
			$Gender = $newBook->getGender();
			$Education = $newBook->getEducation();
			$Occupation = $newBook->getOccupation();
			$TravTime = $newBook->getTravTime();
			$CarUse = $newBook->getCarUse();
			$BlueBook = $newBook->getBlueBook();
			$TIF = $newBook->getTIF();
			$CarType = $newBook->getCarType();
			$RedCar = $newBook->getRedCar();
			$OldClaim = $newBook->getOldClaim();
			$ClaimFrequency = $newBook->getClaimFrequency();
			$Revoked = $newBook->getRevoked();
			$MVR_PTS = $newBook->getMVR_PTS();
			$ClaimAmmount = $newBook->getClaimAmmount();
			$CarAge = $newBook->getCarAge();
			$ClaimFlag = $newBook->getClaimFlag();
			$UrbanCity = $newBook->getUrbanCity();

			$statement->bind_param('ddsddddsdssssdsddssddsdddds', $Id, $KidsDrive, $DOB, $Age, $HomeKids, $YOJ, $Income, $Parent, $HomeValue, $MStatus, $Gender, $Education, 
									$Occupation, $TravTime, $CarUse, $BlueBook, $TIF, $CarType, $RedCar, $OldClaim, $ClaimFrequency, $Revoked, 
									$MVR_PTS, $ClaimAmmount, $CarAge, $ClaimFlag, $UrbanCity);
			$result = $statement->execute();
			if ($result == FALSE)
			{
				$errorMessage = $statement->error;
			}
			$statement->close();
			$connection->close();
			if ($result == TRUE)
			{
				// We need to return the status as 204 (no content) rather than 200 (OK) since
				// we are not returning any data
				$this->noContentResponse();
			}
			else
			{
				$this->errorResponse($errorMessage);
			}
		}
	}

	public function performPut($url, $parameters, $requestBody, $accept) 
	{
		global $dbserver, $dbusername, $dbpassword, $dbdatabase;

		$newBook = $this->extractDriverFromJSON($requestBody);
		$connection = new mysqli($dbserver, $dbusername, $dbpassword, $dbdatabase);
		if (!$connection->connect_error)
		{
			$sql = "update data set KIDSDRIVE = ?, DOB = ?, AGE = ?, HOMEKIDS = ?, YOJ = ?, INCOME = ?, PARENT = ?, HOME_VAL = ?, MSTATUS = ?, GENDER = ?, EDUCATION = ?, OCCUPATION = ?, TRAVTIME = ?, 
			CAR_USE = ?, BLUEBOOK = ?, TIF = ?, CAR_TYPE = ?, RED_CAR = ?, OLDCLAIM = ?, CLM_FREQ = ?, REVOKED = ?, MVR_PTS = ?, CLM_AMT = ?, CAR_AGE = ?, CLAIM_FLAG = ?, URBANICITY = ? where ID = ?";
			// We pull the fields of the book into local variables since 
			// the parameters to bind_param are passed by reference.
			$statement = $connection->prepare($sql);

			$Id = $newBook->getId();
			$KidsDrive = $newBook->getKidsDrive();
			$DOB = $newBook->getDOB();
			$Age = $newBook->getAge();
			$HomeKids = $newBook->getHomeKids();
			$YOJ = $newBook->getYOJ();
			$Income = $newBook->getIncome();
			$Parent = $newBook->getParent();
			$HomeValue = $newBook->getHomeValue();
			$MStatus = $newBook->getMStatus();
			$Gender = $newBook->getGender();
			$Education = $newBook->getEducation();
			$Occupation = $newBook->getOccupation();
			$TravTime = $newBook->getTravTime();
			$CarUse = $newBook->getCarUse();
			$BlueBook = $newBook->getBlueBook();
			$TIF = $newBook->getTIF();
			$CarType = $newBook->getCarType();
			$RedCar = $newBook->getRedCar();
			$OldClaim = $newBook->getOldClaim();
			$ClaimFrequency = $newBook->getClaimFrequency();
			$Revoked = $newBook->getRevoked();
			$MVR_PTS = $newBook->getMVR_PTS();
			$ClaimAmmount = $newBook->getClaimAmmount();
			$CarAge = $newBook->getCarAge();
			$ClaimFlag = $newBook->getClaimFlag();
			$UrbanCity = $newBook->getUrbanCity();

			$statement->bind_param('dsddddsdssssdsddssddsddddsd', $KidsDrive, $DOB, $Age, $HomeKids, $YOJ, $Income, $Parent, $HomeValue, $MStatus, $Gender, $Education, 
									$Occupation, $TravTime, $CarUse, $BlueBook, $TIF, $CarType, $RedCar, $OldClaim, $ClaimFrequency, $Revoked, 
									$MVR_PTS, $ClaimAmmount, $CarAge, $ClaimFlag, $UrbanCity, $Id);
			$result = $statement->execute();
			if ($result == FALSE)
			{
				$errorMessage = $statement->error;
			}
			$statement->close();
			$connection->close();
			if ($result == TRUE)
			{
				// We need to return the status as 204 (no content) rather than 200 (OK) since
				// we are not returning any data
				$this->noContentResponse();
			}
			else
			{
				$this->errorResponse($errorMessage);
			}
		}
	}
	

    public function performDelete($url, $parameters, $requestBody, $accept) 
    {
		global $dbserver, $dbusername, $dbpassword, $dbdatabase;
		
		if (count($parameters) == 2)
		{
			$connection = new mysqli($dbserver, $dbusername, $dbpassword, $dbdatabase);
			if (!$connection->connect_error)
			{
				$id = $parameters[1];
				$sql = "delete from data where Id = ?";
				$statement = $connection->prepare($sql);
				$statement->bind_param('i', $id);
				$result = $statement->execute();
				if ($result == FALSE)
				{
					$errorMessage = $statement->error;
				}
				$statement->close();
				$connection->close();
				if ($result == TRUE)
				{
					// We need to return the status as 204 (no content) rather than 200 (OK) since
					// we are not returning any data
					$this->noContentResponse();
				}
				else
				{
					$this->errorResponse($errorMessage);
				}
			}
		}
    }

    private function getAlldrivers()
    {
		global $dbserver, $dbusername, $dbpassword, $dbdatabase;
	
		$connection = new mysqli($dbserver, $dbusername, $dbpassword, $dbdatabase);
		if (!$connection->connect_error)
		{
			$query = "select * from data";
			if ($result = $connection->query($query))
			{
				while ($row = $result->fetch_assoc())
				{
					$this->drivers[] = new driver($row["ID"], $row["KIDSDRIVE"], $row["DOB"], $row["AGE"], $row["HOMEKIDS"], $row["YOJ"], 
					$row["INCOME"], $row["PARENT"], $row["HOME_VAL"], $row["MSTATUS"], $row["GENDER"], 
					$row["EDUCATION"], $row["OCCUPATION"], $row["TRAVTIME"], $row["CAR_USE"], $row["BLUEBOOK"], 
					$row["TIF"], $row["CAR_TYPE"], $row["RED_CAR"], $row["OLDCLAIM"], $row["CLM_FREQ"], 
					$row["REVOKED"], $row["MVR_PTS"], $row["CLM_AMT"], $row["CAR_AGE"], $row["CLAIM_FLAG"], 
					$row["URBANICITY"] );
				}
				$result->close();
			}
			$connection->close();
		}
	}	 

    private function getdriverById($id)
    {
		global $dbserver, $dbusername, $dbpassword, $dbdatabase;
		
		$connection = new mysqli($dbserver, $dbusername, $dbpassword, $dbdatabase);
		if (!$connection->connect_error)
		{
			$query = "select * from data where ID = ?";
			$statement = $connection->prepare($query);
			$statement->bind_param('i', $id);
			$statement->execute();
			$statement->store_result();
			$statement->bind_result($id, $kidsdrive, $dob, $age, $homekids, $yoj, $income, $parent, $home_val, $mstatus, $gender, $education, $occupation, $travtime, $car_use, $bluebook, $tif, $car_type, $red_car, $oldclaim, $clm_freq, $revoked, $mvr_pts, $clm_amt, $car_age, $claim_flag, $urbanicity);
			if ($statement->fetch())
			{
				return new driver($id, $kidsdrive, $dob, $age, $homekids, $yoj, $income, $parent, $home_val, $mstatus, $gender, $education, $occupation, $travtime, $car_use, $bluebook, $tif, $car_type, $red_car, $oldclaim, $clm_freq, $revoked, $mvr_pts, $clm_amt, $car_age, $claim_flag, $urbanicity);
			}
			else
			{
				return null;
			}
			$statement->close();
			$connection->close();
		}
	}	

    private function getdriversByDate($year, $month, $day)
    {
		global $dbserver, $dbusername, $dbpassword, $dbdatabase;
	
		$connection = new mysqli($dbserver, $dbusername, $dbpassword, $dbdatabase);
		if (!$connection->connect_error)
		{
			$date = $year."-".$month."-".$day;
			$query = "select id, title, author, genre, publishdate, description, price from drivers where publishdate >= ?";
			$statement = $connection->prepare($query);
			$statement->bind_param('s', $date);
			$statement->execute();
			$statement->store_result();
			$statement->bind_result($id, $title, $author, $genre, $publishdate, $description, $price);
			while ($statement->fetch())
			{
				$this->drivers[] = new driver($id, $title, $author, $genre, $publishdate, $description, $price);
			}
			$statement->close();
			$connection->close();
		}
	}	 

	private function extractDriverFromJSON($requestBody)
	{
		$driverArray = json_decode($requestBody, true);
		$driver = new Driver(
			$driverArray['Id'],
			$driverArray['KidsDrive'],
			$driverArray['DOB'],
			$driverArray['Age'],
			$driverArray['HomeKids'],
			$driverArray['YOJ'],
			$driverArray['Income'],
			$driverArray['Parent'],
			$driverArray['HomeVal'],
			$driverArray['MStatus'],
			$driverArray['Gender'],
			$driverArray['Education'],
			$driverArray['Occupation'],
			$driverArray['TravTime'],
			$driverArray['CarUse'],
			$driverArray['BlueBook'],
			$driverArray['TIF'],
			$driverArray['CarType'],
			$driverArray['RedCar'],
			$driverArray['OldClaim'],
			$driverArray['CLMFreq'],
			$driverArray['Revoked'],
			$driverArray['MVRPts'],
			$driverArray['ClaimAmmount'],
			$driverArray['CarAge'],
			$driverArray['ClaimFlag'],
			$driverArray['UrbanCity']
		);
		unset($driverArray);
		return $driver;

	}
}
?>
